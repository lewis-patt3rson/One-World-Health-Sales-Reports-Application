package assignment2;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JDialog;
import javax.swing.*;

public class displayStockForm extends JDialog implements ActionListener {
	
	HashMap<String, Product> products = new HashMap<String, Product>(50);
	private JPanel jpHeader, jpTitle, jpDisplay;
	private JLabel lblHeader, lblTitle;
	private JButton jbExit;
	private JTextArea taDisplay;
	displayStockForm(HashMap productMap)
	{
		
		products = productMap;
		Iterator i = products.entrySet().iterator();
		
		load();
		
	}
	
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		getContentPane().add(c, gc);
		
	}
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		con.add(c,gc);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jbExit)
		{
			dispose();
		}
	}

	public void load()
	{
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		jpHeader = new JPanel();
		jpTitle = new JPanel();
		jpDisplay = new JPanel();
		
		jpHeader.setLayout(new GridBagLayout());
		jpTitle.setLayout(new GridBagLayout());
		jpDisplay.setLayout(new GridBagLayout());
		
		addComp(jpHeader,0,0,1,1,1,0);
		addComp(jpTitle,0,1,1,1,1,0);
		addComp(jpDisplay,0,2,1,1,1,1);
		
		lblHeader = new JLabel("Display Stock");
		
		addComp(jpHeader, lblHeader,0,0,1,1,1,1);
		
		lblTitle = new JLabel("Product No:       Name:               Price:         Stock Level:          No Sold:  Size:");
		addComp(jpTitle, lblTitle,0,0,1,1,1,0);
		lblTitle.setFont(new Font("Courier New", Font.PLAIN, 12));
		
		
		taDisplay = new JTextArea();
		taDisplay.setFont(new Font("Courier New", Font.PLAIN, 12));
		taDisplay.setEditable(false);
		jbExit = new JButton("Exit");
		addComp(jpDisplay, taDisplay,0,0,2,1,1,1);
		addComp(jpDisplay, jbExit,1,1,1,1,1,0);
		jbExit.addActionListener(this);	
		
		displayAll();
	}
	
	
	
	public void displayAll()
	{
		String dis = "";
		
		Iterator it = products.entrySet().iterator();
		while(it.hasNext())
		{		
			Map.Entry me = (Entry) it.next();
			
			dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", products.get(me.getKey()).getProductID(),products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize());
			dis += ("\n");
		}
		taDisplay.setText(dis);
	}
}
