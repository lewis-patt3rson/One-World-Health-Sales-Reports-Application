package assignment2;

import java.awt.*;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.*;

public class addProductForm extends JDialog implements ActionListener {

	HashMap<String, Product> products = new HashMap<String, Product>(50);
	private JLabel lblHeader, lblProductID, lblID, lblName, lblSize, lblCategory, lblStockLevel, lblUnitPrice;
	private JTextField tfName, tfSize, tfStockLevel, tfUnitPrice;
	private JComboBox cmbCategory;
	private JButton jbAdd, jbReset, jbExit;
	Product newP;
	private int count, stock;
	private double price;
	addProductForm(HashMap productsMap)
	{
		//Change categories to text file - notes on moodle
		products = productsMap;		
		load();	
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jbAdd)
		{
			add();
		}
		else if(e.getSource() == jbReset)
		{
			tfName.setText("");
			tfSize.setText("");
			tfStockLevel.setText("");
			tfUnitPrice.setText("");
		}
		else if(e.getSource() == jbExit)
		{
			if(newP.getName() == "")
			{
				newP.exitAdd();
			}
			dispose();
		}
		
	}
	
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	public void load()
	{
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		newP = new Product();
		cn.setBackground(Color.LIGHT_GRAY);
		lblProductID = new JLabel("Product ID: ");
		lblID = new JLabel("" + newP.getProductID());
		lblName = new JLabel("Stock Name: ");
		lblSize = new JLabel("Size");
		lblCategory = new JLabel("Category: ");
		lblStockLevel = new JLabel("Stock Amount: ");
		lblUnitPrice = new JLabel("Price: ");
		lblHeader = new JLabel("Add product" , JLabel.CENTER);
		
		
		String[] cat = {"...", "Beauty", "Food", "Sports Nutrition", "Vitamins", "Weight Loss"};
		cmbCategory = new JComboBox(cat);
		
		tfName = new JTextField();
		tfSize = new JTextField();
		tfStockLevel = new JTextField();
		tfUnitPrice = new JTextField();
		
		jbAdd = new JButton("Add");
		jbReset = new JButton("Reset");
		jbExit = new JButton("Exit");
		
		addComp(lblHeader, 0,0,4,1,1,1);
		addComp(lblProductID, 0,1,1,1,1,1);
		addComp(lblID, 1,1,1,1,1,1);
		addComp(lblName, 0,2,1,1,1,1);
		addComp(lblCategory, 0,3,1,1,1,1);
		addComp(lblStockLevel, 0,4,1,1,1,1);
		addComp(lblUnitPrice, 0,5,1,1,1,1);
		addComp(tfName, 1,2,2,1,1,1);
		addComp(tfSize, 1,6,1,1,1,1);
		addComp(tfStockLevel, 1,4,1,1,1,1);
		addComp(tfUnitPrice, 1,5,1,1,1,1);
		addComp(lblSize, 0,6,1,1,1,1);
		addComp(jbAdd,0,7,1,1,1,1);
		addComp(jbReset,1,7,1,1,1,1);
		addComp(jbExit,2,7,1,1,1,1);
		addComp(cmbCategory,1,3,2,1,1,1);
		
		jbAdd.addActionListener(this);
		jbReset.addActionListener(this);
		jbExit.addActionListener(this);
		cmbCategory.addActionListener(this);
	}
	
	public void add()
	{
		
		
		
		if(addVal() == true)
		{
			newP.setName(tfName.getText().trim());
			newP.setSize(tfSize.getText().trim());
			newP.setStockLevel(stock);
			newP.setUnitPrice(price);
			switch(cmbCategory.getSelectedIndex())
			{
			case 1: newP.setCategory("Beauty"); break;
			case 2: newP.setCategory("Food"); break;
			case 3: newP.setCategory("Sports Nutrition"); break;
			case 4: newP.setCategory("Vitamins"); break;
			case 5: newP.setCategory("Weight Loss"); break;
			default: break;
			}
			String id = "" + newP.getProductID();
			System.out.print("\n\n\tCount: " + newP.getCount() + "\t" + newP.getProductID() + "\n\n");
			products.put(id, newP);
			System.out.print(id);
			
			
			
			int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog (null, "You have added item: " + newP.getName().toString() +"\nWould you like to add another item?","Item successfully added", dialogButton);
            if(dialogResult == JOptionPane.YES_OPTION)
            {
            	
            	newP = new Product();
            	tfName.setText("");
    			tfSize.setText("");
    			tfStockLevel.setText("");
    			tfUnitPrice.setText("");
    			lblID.setText(""+newP.getProductID());
    			cmbCategory.setSelectedIndex(0);
    			count = 0;
            }
            else if(dialogResult == JOptionPane.NO_OPTION)
            {
            	dispose();
            }
            
		}		
	}

	public boolean addVal()
	{
		boolean val = false;
		
		String name = tfName.getText().trim();
		String error = "";
		String e1 = "", e2 = "";
		count = 0; stock = 0;
		price = 0.0;
		if(name.length() < 3 || name.length() > 20)
		{
			error = "Name must be between 3 and 20 characters.\n";
		}
		for(int i = 0; i <name.length(); i++)
		{
			if(name.charAt(i) == ' ')
			{
				if(count > 0)
				{
					e1 = "You can only have one space in a name";
				}
				count++;
			}
			else if(Character.isLetter(name.charAt(i)) == false && Character.isDigit(name.charAt(i)) == false )
			{
				System.out.print(name.charAt(i) + "\n");
				e2 = "Names must only contain either letters, numbers or a space.\n";
			}
			
		}
		
		error += e1;
		error += e2;
		e1 = "";
		e2 = "";
		if(error.length() == 0)
		{
			if(cmbCategory.getSelectedIndex() == 0)
			{
				error = "You must choose a category.\n";
			}
		}
		
		if(error.length() == 0)
		{
			try {
			stock = Integer.parseInt(tfStockLevel.getText().trim());
			}
			catch(Exception ee)
			{
				error = "Enter a valid value for stock.\n";
			}
			if(tfStockLevel.getText().trim().length() > 0)
			{
				for(int i = 0; i < tfStockLevel.getText().trim().length(); i++)
				{
					if(Character.isDigit(tfStockLevel.getText().trim().charAt(i)) == false)
					{
						e1 = "Stock level can only be a numeric value between 0 and 100.\n";
					}
				}
				if(e1.length() == 0)
				{
					
					if(stock < 0 || stock > 100)
					{
						e2 = "Stock can't be less than 0 or more than 100.\n";
					}
				}
			}
			else
			{
				error = "Stock must have a value\n";
			}
		}
		
		error += e1;
		error += e2;
		e1 = "";
		e2 = "";
		if(tfUnitPrice.getText().trim().length() == 0)
		{
			error = "Please enter a value for price\n";
		}
		else
		{
			try
			{
				
				price = Double.parseDouble(tfUnitPrice.getText().trim());
				if(price > 100 || price < 5)
				{
					error = "Price must be within 5 and 100 pounds.\n";
				}
			}
			catch(Exception e)
			{
				error = "Please enter a valid value for price.\n Either with or without decimals\n";
			}
		}	
		
		if(error.length() == 0)
		{
			String size = tfSize.getText().trim();
			if(size.length() < 3 || size.length() > 20)
			{
				error = "size must be between 3 and 20 characters.\n";
			}
			for(int i = 0; i <size.length(); i++)
			{
				if(size.charAt(i) == ' ')
				{
					System.out.print(count + "\n");
					if(count > 0)
					{
						e1 = "You can only have one space in the size\n";
					}
					count++;
				}
				else if(Character.isLetter(size.charAt(i)) == false && Character.isDigit(size.charAt(i)) == false )
				{
					System.out.print(size.charAt(i) + "\n");
					e2 = "Size must only contain either letters, numbers of spaces.\n";
				}
				
			}
		}
		
		error += e1;
		error += e2;
		e1 = "";
		e2 = "";
		if(error.length() > 0)
			JOptionPane.showMessageDialog(null, String.format(error));
		else
		{
			val = true;
		}
		
		return val;
	}
}
