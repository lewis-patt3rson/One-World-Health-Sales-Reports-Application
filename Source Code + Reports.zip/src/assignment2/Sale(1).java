package assignment2;

import java.time.*;
import java.util.ArrayList;

public class Sale implements java.io.Serializable{

	
	private static int countSales = 100;
	private int basketSize, salesID;
	private String customerName;
	private String productCodes;
	LocalDateTime dateSold;
	double totalPrice;
	
	Sale()
	{
		countSales++;
		salesID = countSales;
		customerName = "";
		dateSold = LocalDateTime.now();
		totalPrice = 0.0;
		basketSize = 0;
	}
	
	Sale(int saleID, String customerName, LocalDateTime dateSold, double totalPrice, int basketSize)
	{
		this.salesID = saleID;
		this.customerName = customerName;
		this.dateSold = dateSold;
		this.totalPrice = totalPrice;
		this.basketSize = basketSize;
	}
	
	public int getSaleID() {
		return salesID;
	}
	public void setSaleID(int saleID) {
		this.salesID = saleID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getProductCodes() {
		return productCodes;
	}
	public void setProductCodes(String productCodes) {
		this.productCodes = productCodes;
	}
	public LocalDateTime getDateSold() {
		return dateSold;
	}
	public void setDateSold(LocalDateTime dateSold) {
		this.dateSold = dateSold;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getBasketSize() 
	{
		return basketSize;
	}

	public void setBasketSize(int basketSize) {
		
		this.basketSize = basketSize;
	}
	public void setCount(int count)
	{
		this.countSales = count;
	}
	public int getCount()
	{
		return countSales;
	}
	public void exitSale()
	{
		countSales--;
	}
}
