package assignment2;

public class showSean {

	private Basket sale;
	showSean()
	{
		sale = new Basket();
	}
}
