package assignment2;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class productsByCategoryForm extends JDialog implements ActionListener{

	HashMap<String, Product> products = new HashMap<String, Product>(50);
	int[] gradeQuant = new int[5];
	private JPanel jpHeader, jpButtons;
	private JLabel lblHeader, lblMessage;
	private JButton jbClear, jbBeauty, jbFood, jbSportsNutrition, jbVitamins, jbWeightLoss, jbExit, jbReport;
	private Product[] p;
	private JTextArea taDisplay, taProductHeader;
	private String selectedCat;
	int count = 0;
	productsByCategoryForm(HashMap productsMap)
	{
		products = productsMap;
		for(int i =0;i<5;i++)
		{
			gradeQuant[i] = 0;
		}
		load();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jbBeauty)
		{
			selectedCat = "";
			byCategory(0);
		}
		else if(e.getSource() == jbFood)
		{
			selectedCat = "";
			byCategory(1);
		}
		else if(e.getSource() == jbSportsNutrition)
		{
			selectedCat = "";
			byCategory(2);
		}
		else if(e.getSource() == jbVitamins)
		{
			selectedCat = "";
			byCategory(3);
		}
		else if(e.getSource() == jbWeightLoss)
		{
			selectedCat = "";
			byCategory(4);
		}
		else if(e.getSource() == jbClear)
		{
			selectedCat = "";
			taDisplay.setText("");
		}
		else if(e.getSource() == jbReport)
		{
			try {
				sendToReport();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if(e.getSource() == jbExit)
		{
			dispose();
		}
	}
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		getContentPane().add(c, gc);
		
	}
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		con.add(c,gc);
	}
	public void load()
	{
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		selectedCat = "";
		jpHeader = new JPanel();
		jpButtons = new JPanel();
		jpHeader.setLayout(new GridBagLayout());
		jpButtons.setLayout(new GridBagLayout());
		
		p = new Product[products.size()];
		Iterator i = products.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry me = (Entry) i.next();	
				p[count] = products.get(me.getKey());
				count++;
				switch(products.get(me.getKey()).getCategory())
				{
				case "Beauty": gradeQuant[0] = (gradeQuant[0] +1); break;
				case "Food": gradeQuant[1] = (gradeQuant[1] +1); break;
				case "Sports Nutrition": gradeQuant[2] = (gradeQuant[2] +1); break;
				case "Vitamins": gradeQuant[3] = (gradeQuant[3] +1); break;
				case "Weight Loss": gradeQuant[4] = (gradeQuant[4] +1); break;
				}					
		}	
		lblHeader = new JLabel("Products By Category");
		lblMessage = new JLabel("Please Choose a category:");
		jbClear = new JButton("Clear");
		jbBeauty = new JButton("Beauty");
		jbFood = new JButton("Food");
		jbSportsNutrition = new JButton("Sports Nutrition");
		jbVitamins = new JButton("Vitamins");
		jbWeightLoss = new JButton("Weight Loss");
		jbExit = new JButton("Exit");
		jbReport = new JButton("Send to report");
		addComp(jpHeader,lblHeader,0,0,1,1,1,0);
		addComp(jpHeader,lblMessage,0,1,1,1,1,0);
		
		addComp(jpButtons, jbBeauty, 0,0,1,1,1,0);
		addComp(jpButtons, jbFood, 1,0,1,1,1,0);
		addComp(jpButtons, jbSportsNutrition, 2,0,1,1,1,0);
		addComp(jpButtons, jbVitamins, 3,0,1,1,1,0);
		addComp(jpButtons, jbWeightLoss, 4,0,1,1,1,0);
		addComp(jpButtons, jbClear, 5,0,1,1,1,0);
		
		jbBeauty.addActionListener(this);
		jbFood.addActionListener(this);
		jbSportsNutrition.addActionListener(this);
		jbVitamins.addActionListener(this);
		jbWeightLoss.addActionListener(this);
		jbClear.addActionListener(this);
		jbExit.addActionListener(this);
		jbReport.addActionListener(this);
		addComp(jpHeader,0,0,1,1,0,0);
		addComp(jpButtons,0,1,1,1,0,0);
		
		taDisplay = new JTextArea();
		taDisplay.setEditable(false);
		taDisplay.setFont(new Font("Courier New", Font.PLAIN, 12));
		taProductHeader = new JTextArea("Product No:       Name:               Price:         Stock Level:          No Sold:  Size:");
		taProductHeader.setEditable(false);
		taProductHeader.setFont(new Font("Courier New", Font.PLAIN, 12));
		addComp(taProductHeader,0,2,2,1,1,0);
		addComp(taDisplay,0,3,2,1,1,1);
		addComp(jbExit,0,4,1,1,0,0);
		addComp(jbReport,1,4,1,1,0,0);
		
	}	
	public void byCategory(int cat)
	{
		String dis = "";
		
//		for(int i = products.size() - 1; i >= 0; i--)
//		{
		Iterator it = products.entrySet().iterator();
		int count = 0;
		while(it.hasNext())
		{
			Map.Entry me = (Entry) it.next();	
			
			switch(cat)
			{
			case 0: 
				selectedCat = "Beauty";
				if(gradeQuant[0] == 0)
				{
					dis = "There are no products of this category";
					
				}
				else if( products.get(me.getKey()).getCategory().equals(selectedCat))
				{
					dis += "\n";
					dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", products.get(me.getKey()).getProductID(),products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize());
					System.out.print("\nDis: " + dis);
				}
				break;
			case 1: 
				selectedCat = "Food";
				if(gradeQuant[1] == 0)
				{
					dis = "There are no products of this category";
					
				}
				else if(products.get(me.getKey()).getCategory().equals(selectedCat))
				{
					dis += "\n";
					dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", products.get(me.getKey()).getProductID(),products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize());
					System.out.print("\nDis: " + dis);
				}
				break;
			case 2: 
				selectedCat = "Sports Nutrition";
				if(gradeQuant[2] == 0)
				{
					dis = "There are no products of this category";
					
				}
				else if( products.get(me.getKey()).getCategory().equals(selectedCat))
				{
					dis += "\n";
					dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", products.get(me.getKey()).getProductID(),products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize());
					
				}
				break;
			case 3: 
				selectedCat = "Vitamins";
				if(gradeQuant[3] == 0)
				{
					dis = "There are no products of this category";
					
				}
				else if( products.get(me.getKey()).getCategory().equals(selectedCat))
				{
					dis += "\n";
					dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", products.get(me.getKey()).getProductID(),products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize());
					
				}
				break;
			case 4: 
				
				selectedCat = "Weight Loss";
				if(gradeQuant[4] == 0)
				{
					dis = "There are no products of this category";
					
				}
				else if( products.get(me.getKey()).getCategory().equals(selectedCat))
				{
					dis += "\n";
					dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", products.get(me.getKey()).getProductID(),products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize());
				}
				break;
			}
		}
		dis += "\n";
		taDisplay.setText(dis);
	}

	public void sendToReport() throws FileNotFoundException
	{
		boolean emptyCat = false;
		int quant = 0;
		if(selectedCat.length() > 0)
		{
		switch(selectedCat)
		{
			case "Beauty": 
				if(gradeQuant[0] == 0)
				{
					emptyCat = true;
				}
				else
				{
					quant = gradeQuant[0];
				}
				break;
			case "Food": 
				if(gradeQuant[1] == 0)
				{
					emptyCat = true;
				}
				else
				{
					quant = gradeQuant[0];
				}
				break;
			case "Sports Nutrition": 
				if(gradeQuant[2] == 0)
				{
					emptyCat = true;
				}
				else
				{
					quant = gradeQuant[0];
				}
				break;
			case "Vitamins": 
				if(gradeQuant[3] == 0)
				{
					emptyCat = true;
				}
				else
				{
					quant = gradeQuant[0];
				}
				break;
			case "Weight Loss": 
				if(gradeQuant[4] == 0)
				{
					emptyCat = true;
				}
				else
				{
					quant = gradeQuant[0];
				}
				break;
			}
			
			if(emptyCat == true)
			{
				JOptionPane.showMessageDialog(null, "There are no products for this category.");
			}
			else
			{
				String s = (selectedCat + "_Products_" + LocalDateTime.now().getDayOfMonth() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getYear() + ".txt");
				File inFile = new File(s);
				PrintWriter in = new PrintWriter(inFile);
				
				in.println("P R O D U C T S   B Y   C A T E G O R Y");
				in.println("---------------------------------------");
				in.println(String.format("CATEGORY CHOSEN: " + selectedCat + "           AMOUNT: " + quant));
				in.println("");
				in.println("Product ID:       Name:               Price:         Stock Level:          No Sold:          Size:");
				in.println("-----------------------------------------------------------------------------------------------------------------");
				
				Iterator i = products.entrySet().iterator();
				while(i.hasNext())
				{
					Map.Entry me = (Entry) i.next();	
					//System.out.print("\n\n: " + );
					if(products.get(me.getKey()).getCategory().equals(selectedCat))
					{
						String price = "";
						price = ("" + products.get(me.getKey()).getUnitPrice());
						in.println(String.format("%-18d%-20s%-15.2f%-22d%-18d%-20s", products.get(me.getKey()).getProductID(), products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getSize()));
					}
				}
				
				in.println("");
				in.println("-----------------------------------------------------------------------------------------------------------------");
				in.println("REPORT FINISHED. DATE: " + LocalDateTime.now());
				in.println("-----------------------------------------------------------------------------------------------------------------");
				
				in.close();
			}
			
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Please choose a category to send to a report.");
		}
		
	}
	
}
