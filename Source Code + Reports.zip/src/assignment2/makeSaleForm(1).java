	package assignment2;
	
	import java.awt.Color;
	import java.awt.Component;
	import java.awt.Container;
	import java.awt.GridBagConstraints;
	import java.awt.GridBagLayout;
	import java.awt.Insets;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.time.LocalDateTime;
	import java.util.*;
	import java.util.Map.Entry;
	import javax.swing.*;
	
	public class makeSaleForm extends JDialog implements ActionListener{
	
	HashMap<String, Product> products = new HashMap<String, Product>(50);
	private JPanel jpExistingProducts, jpTillScreen, jpProductScreen, jpButtons, jpTill;
	private JLabel lblHeader, lblSummary;
	private JTextField tfSearch, tfQuantity, tfName;
	private JTextArea taBasket, taItems;
	private JLabel lblName, lblPrice, lblSize, lblQuantity, lblCustomerName, lblProductNo, lblBasket;
	private JButton jbSearchAdd, jbClear, jbRemove, jbFinish;
	private Product addP;
	private JComboBox cmbQuantity;
	public Sale newSale;
	int items = 0; double totPrice = 0;
	LinkedList<Sale> sales = new LinkedList<Sale>();
	private int[] productQuant = new int[products.size()];
	private String pCodes;
	makeSaleForm(HashMap productsMap, LinkedList salesList)
	{
		sales = salesList;
		newSale = new Sale();
		newSale.setCount(100 + sales.size());
		newSale.setSaleID(newSale.getCount());
		products = productsMap;
		load();
		Iterator i = products.entrySet().iterator();
		int count = 0;
		productQuant = new int[products.size()];
		while(i.hasNext())
		{
			
			Map.Entry me = (Entry) i.next();
			productQuant[count] = products.get(me.getKey()).getStockLevel();
			count = count +1;		
		}
		
		
	}
	
	public void load()
	{
//		Product addP = new Product();
//		addP.setCount((addP.getCount() - 1));
//		Sale newSale = new Sale();
//		newSale.setCount((newSale.getCount()-1));
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		jpExistingProducts = new JPanel();
		jpTillScreen = new JPanel();
		jpTill = new JPanel();
		jpProductScreen = new JPanel();
		jpButtons = new JPanel();
		jpExistingProducts.setLayout(new GridBagLayout());
		jpTillScreen.setLayout(new GridBagLayout());
		jpTill.setLayout(new GridBagLayout());
		jpProductScreen.setLayout(new GridBagLayout());
		jpButtons.setLayout(new GridBagLayout());
		addComp(jpExistingProducts,0,0,1,1,1,1);
		addComp(jpTill,1,0,1,1,1,1);
		addComp(jpButtons,2,0,1,1,1,1);
		jpProductScreen.setVisible(false);
		jpExistingProducts.setBackground(Color.red);
		
		
		//Adding to the till screen
		lblHeader = new JLabel("Sale: " + newSale.getSaleID() + " - Till - " + LocalDateTime.now().toString());
		lblSummary = new JLabel("Items:         Total:");
		
		addComp(jpTill, lblHeader,0,0,1,1,1,0);
		addComp(jpTill, jpTillScreen,0,1,1,1,1,1);
		addComp(jpTill, jpProductScreen,0,1,1,1,1,1);
		addComp(jpTill, lblSummary,0,2,1,1,1,0);
		
		lblCustomerName = new JLabel("Customer Name:");
		lblProductNo = new JLabel("Enter Product Number");
		lblBasket = new JLabel("Basket:");
		tfSearch = new JTextField();
		tfName = new JTextField();
		taBasket = new JTextArea();
		taBasket.setEditable(false);
		
		addComp(jpTillScreen, lblProductNo,0,0,1,1,0,0);
		addComp(jpTillScreen, tfSearch,0,1,1,1,0,0);
		addComp(jpTillScreen, lblCustomerName,0,2,1,1,0,0);
		addComp(jpTillScreen, tfName,0,3,1,1,0,0);
		addComp(jpTillScreen, lblBasket,0,4,1,1,0,0);
		addComp(jpTillScreen, taBasket,0,5,1,1,1,1);
		
		taItems = new JTextArea("Products - In Stock");
		taItems.setEditable(false);
		Iterator i = products.entrySet().iterator();
		String inStock = "";
		while(i.hasNext())
		{
			
			Map.Entry me = (Entry) i.next();
			if(products.get(me.getKey()).getStockLevel() > 0)
			{
				inStock = "Y";
			}
			else
			{
				inStock = "N";
			}
			taItems.append("\n" + products.get(me.getKey()).getProductID() + ": " + products.get(me.getKey()).getName() + "   " + inStock); 
			
		}
		
		addComp(jpExistingProducts, taItems,0,1,1,1,1,1);
		
		
		lblName = new JLabel("Name: ");
		lblPrice = new JLabel("Price: ");
		lblSize = new JLabel("Size: ");
		lblQuantity = new JLabel("Quantity: ");
		tfQuantity = new JTextField("");
		addComp(jpProductScreen, lblName,0,0,1,1,0,0);
		addComp(jpProductScreen, lblPrice,0,1,1,1,0,0);
		addComp(jpProductScreen, lblSize,0,2,1,1,0,0);
		addComp(jpProductScreen, lblQuantity,0,3,1,1,0,0);
		addComp(jpProductScreen, tfQuantity,1,3,1,1,1,0);
		
		
		jbSearchAdd = new JButton("Search");
		jbSearchAdd.addActionListener(this);
		jbClear = new JButton("Clear Order");
		jbClear.addActionListener(this);
		jbRemove = new JButton("Remove Item");
		jbRemove.addActionListener(this);
		jbFinish = new JButton("Cancel");
		jbFinish.addActionListener(this);
		
		addComp(jpButtons, jbSearchAdd,0,0,1,1,0,0);
		addComp(jpButtons, jbClear,0,1,1,1,0,0);
		addComp(jpButtons, jbRemove,0,2,1,1,0,0);
		addComp(jpButtons, jbFinish,0,3,1,1,0,0);
		
		lblSummary.setText("Items: " + newSale.getBasketSize() +"\tTotal: " + newSale.getTotalPrice());
		
	}
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		getContentPane().add(c, gc);
		
	}
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		con.add(c,gc);
	}
	@Override
	public void actionPerformed(ActionEvent e)
	{	
		if(e.getSource() == jbSearchAdd)
		{
			if(jbSearchAdd.getText() == "Search")
			loadProduct();
			else
			addItem();
		}
		else if(e.getSource() == jbClear)
		{
			clearOrder();
		}
		else if(e.getSource() == jbFinish)
		{
			if(jbFinish.getText() == "Cancel")
			{
				newSale.setCount(sales.get(0).getCount()-1);
				dispose();
			}
			else
			{
				finishOrder();
			}
		}
		
		
		if(newSale.getBasketSize() > 0)
		{
			jbFinish.setText("Finish");
		}
		else
		{
			jbFinish.setText("Cancel");
		}
		
	}

	
	public void loadProduct()
	{		
		if(products.containsKey(tfSearch.getText()))
		{
			addP = products.get(tfSearch.getText());
			if(addP.getStockLevel() > 0)
			{
				jpProductScreen.setVisible(true);
				jpTillScreen.setVisible(false);
				lblName.setText("Name: " + addP.getName());
				lblPrice.setText("Price: " + addP.getUnitPrice());
				lblSize.setText("Size: " + addP.getSize());
				
				
				jbSearchAdd.setText("Add");
				
				
			}
			else
			{
				JOptionPane.showMessageDialog(null, String.format("Product is out of stock."));
			}
		}	
		else
		{
			JOptionPane.showMessageDialog(null, String.format("Product not found."));
		}
	}
	
	public void addItem()
	{
		int quantity = 0;
		
		try {
			if(Integer.parseInt(tfQuantity.getText().trim()) > addP.getStockLevel())
			{
				JOptionPane.showMessageDialog(null, String.format("This exceeds the stock amount of this item"));
			}
			else
			{
				quantity = Integer.parseInt(tfQuantity.getText().trim());
				totPrice += (quantity * addP.getUnitPrice());
				items += quantity;
				newSale.setBasketSize(items);
				newSale.setTotalPrice(totPrice);
				lblSummary.setText("Items: " + newSale.getBasketSize() +"\tTotal: " + newSale.getTotalPrice());
				for(int j = 0; j < quantity; j++)
				{
					
				}
					
				for(int i = 0; i <  quantity; i++)
				{
					taBasket.append("\n" + addP.getProductID() + ": " + addP.getName() + " - " + addP.getUnitPrice());
					pCodes += (tfSearch.getText() + ",");
				}
				
				newSale.setProductCodes(pCodes.substring(4));
				jpTillScreen.setVisible(true);
				jpProductScreen.setVisible(false);
				addP.setStockLevel(addP.getStockLevel() - (quantity) );
				jbSearchAdd.setText("Search");
				tfSearch.setText("");
				tfQuantity.setText("");
				
				updateProducts();
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, String.format("Please enter a valid amount."));
		}	
	}
	
	public void clearOrder()
	{	
		taBasket.setText("Basket");
		pCodes = "";
		newSale.setBasketSize(0);
		newSale.setTotalPrice(0.0);
		items = 0;
		totPrice = 0;
		newSale.setProductCodes(pCodes);
		lblSummary.setText("Items: " + newSale.getBasketSize() +"\tTotal: " + newSale.getTotalPrice());
    	
		Iterator i = products.entrySet().iterator();
		int count = 0;
		while(i.hasNext())
		{
			
			Map.Entry me = (Entry) i.next();
			products.get(me.getKey()).setStockLevel(productQuant[count]);
			count = count +1;		
		}
		updateProducts();		
		jbFinish.setText("Cancel");
		//codes = "";
		tfName.setText("");
	}
	
	public void updateProducts()
	{
		Iterator i = products.entrySet().iterator();
		String inStock = "";
		taItems.setText("Products - In Stock");
		while(i.hasNext())
		{				
			Map.Entry me = (Entry) i.next();
			if(products.get(me.getKey()).getStockLevel() > 0)
			{
				inStock = "Y";
			}
			else
			{
				inStock = "N";
			}
			taItems.append("\n" + products.get(me.getKey()).getProductID() + ": " + products.get(me.getKey()).getName() + "   " + inStock); 		
		}
	}
	
	public void finishOrder()
	{
		if(newSale.getBasketSize() > 0)
		{
			if(nameVal() == true)
			{
				newSale.setCustomerName(tfName.getText().trim());
				sales.push(newSale);
				sales.size();
				System.out.print(newSale.getSaleID() +"\n" + newSale.getProductCodes() + "\n" + sales.size());
				JOptionPane.showMessageDialog(null, "Sale made.");
				
				String[] codes = newSale.getProductCodes().split(",");
				System.out.print("------------" + newSale.getProductCodes() + "------------");
				System.out.print("\n\n" + codes[0] + "----\n\n");
				for(int i = 0; i < codes.length; i++)
				{
					products.get(codes[i]).setNoSold((products.get(codes[i]).getNoSold() + 1));
				}
				
				
				dispose();
			}
		}
		else
		JOptionPane.showMessageDialog(null, String.format("You must add atleast one item to your basket."));
	}
	
	public boolean nameVal()
	{
		boolean val = true;
		String name = tfName.getText().trim();
		String error = "";
		String e1 = "", e2 = "";
		int count = 0;
		if(name.length() < 3 || name.length() > 20)
		{
			error = "Name must be between 3 and 20 characters.\n";
		}
		for(int i = 0; i <name.length(); i++)
		{
			if(name.charAt(i) == ' ')
			{
				if(count > 0)
				{
					e1 = "You can only have one space in a name";
				}
				count++;
			}
			else if(Character.isLetter(name.charAt(i)) == false)
			{
				System.out.print(name.charAt(i) + "\n");
				e2 = "Names must only contain either letters.\n";
			}
			
		}
		
		error += e1;
		error += e2;
		if(error.length() > 0)
		{
			JOptionPane.showMessageDialog(null, String.format(error));
			val = false;
		}
		return val;
	}
	
	
	
	
	
	
	
	
}