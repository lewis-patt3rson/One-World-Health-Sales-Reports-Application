package assignment2;

public class Basket {
Basket()
{
	
}
}
