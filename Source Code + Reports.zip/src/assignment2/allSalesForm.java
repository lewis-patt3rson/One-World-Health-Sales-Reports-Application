package assignment2;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.LinkedList;

import javax.swing.JDialog;
import javax.swing.*;

public class allSalesForm extends JDialog implements ActionListener {

	
	LinkedList<Sale> sales = new LinkedList<Sale>();
	private JPanel jpHeader, jpDisplay, jpButtons;
	private JLabel lblHeader, lblMessage;
	private JTextArea taSummary, taDisplay;
	private JButton jbExit, jbReport;
	private int totPrice = 0, stockSold = 0;
	Sale[] s;
	allSalesForm(LinkedList salesList)
	{
		sales = salesList;
		
//		s = new Sale[sales.size()];
//		 
//		for(int i = 0; i < sales.size(); i++)
//		{
//			s[i] = new Sale();
//			
//		}
		
		
		
		for(int i = 0; i < sales.size(); i++)
		{
			System.out.print(sales.get(0).getProductCodes());
//			s[i] = sales.get(i);
			totPrice += sales.get(0).getTotalPrice();
			stockSold += sales.get(0).getBasketSize();
		}
		load();
	}
	
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		getContentPane().add(c, gc);
		
	}
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		con.add(c,gc);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == jbExit)
		{
			dispose();
		}
		else if(e.getSource() == jbReport)
		{
			try {
				sendToReport();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	public void load()
	{
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		cn.setBackground(Color.LIGHT_GRAY);
		jpHeader = new JPanel();
		jpDisplay = new JPanel();
		jpButtons = new JPanel();
		jpHeader.setLayout(new GridBagLayout());
		jpDisplay.setLayout(new GridBagLayout());
		jpButtons.setLayout(new GridBagLayout());
		
		lblHeader = new JLabel("All Sales");
		lblMessage = new JLabel("All Sales are listed below:");
		
		taSummary = new JTextArea();
		taDisplay = new JTextArea();
		taSummary.setEditable(false);
		taDisplay.setEditable(false);
		
		jbExit = new JButton("Exit");
		jbReport = new JButton("Send To Report");
		jbExit.addActionListener(this);
		jbReport.addActionListener(this);
		
		addComp(jpHeader,0,0,1,1,1,0);
		addComp(jpHeader, lblHeader,0,0,1,1,1,0);
		addComp(jpHeader, lblMessage,0,1,1,1,1,0);
		
		addComp(jpDisplay,0,1,1,1,1,1);
		addComp(jpDisplay, taSummary,0,0,1,1,1,0);
		addComp(jpDisplay, taDisplay,0,1,1,1,1,1);
		
		addComp(jpButtons,0,2,2,1,1,0);
		addComp(jpButtons, jbExit,0,0,2,1,1,0);
		addComp(jpButtons, jbReport,2,0,1,1,1,0);
		
		
		String display = "";
		for(int i = sales.size() - 1; i >= 0; i--)
		{
			
			String prods = sales.get(i).getProductCodes();
			  StringBuffer sb= new StringBuffer(prods);
			    sb.deleteCharAt(sb.length()-1);
				display += ("Sales Number:" + (sales.get(i).getSaleID())) + "\nCustomer Name: " + sales.get(i).getCustomerName() +"\nProducts Sold: " + sales.get(i).getBasketSize() + "\nProducts: " + sb 
						+ "\nTotal Price: " + sales.get(i).getTotalPrice() + "\nDate Sold: " + LocalDateTime.now().getDayOfMonth() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getYear() 
						+ "\n-----------------------------------------------------------------\n\n";		
		}
		taDisplay.setText(display);
		taSummary.setText("Total Sales: " + sales.size() + "\tTotal Amount Made: " + totPrice +
				"\tStock Amount Sold: " + stockSold);
	}
	
	
	public void sendToReport() throws FileNotFoundException
	{
		
		String s = ("All_Sales_" + LocalDateTime.now().getDayOfMonth() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getYear() + ".txt");
		File inFile = new File(s);
		PrintWriter in = new PrintWriter(inFile);
		in.println("A L L   S A L E S");
		in.println("-----------------");
		in.println("Sales Made: " + sales.size() + "     Total Stock Sold: " + stockSold + "        Total Amount Received: " + totPrice);
		in.println("------------------------------------------------------------------------------------------------------------------");
		
		
		for(int i = sales.size() - 1; i >= 0; i--)
		{
			in.println("");
			in.println("Sales Number:" + (sales.get(i).getSaleID()));
			in.println("");
			in.println("Customer Name: " + sales.get(i).getCustomerName());
			String prods = sales.get(i).getProductCodes();
			in.println("Products Sold: " + sales.get(i).getBasketSize());
		    StringBuffer sb= new StringBuffer(prods);
		    sb.deleteCharAt(sb.length()-1);
			in.println("Products: " + sb);
			in.println("Total Price: " + sales.get(i).getTotalPrice());
			in.println("Date Sold: " + LocalDateTime.now().getDayOfMonth() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getYear());
			in.println("------------------------------------------------------------------------------------------------------------------");			
		}
		
		
		in.println("");
		in.println("------------------------------------------------------------------------------------------------------------------");
		in.println("REPORT FINISHED. DATE: " + LocalDateTime.now().getDayOfMonth() + "-" + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getYear());
		in.println("------------------------------------------------------------------------------------------------------------------");
		
		
		
		in.close();
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
