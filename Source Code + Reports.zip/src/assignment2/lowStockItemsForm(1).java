package assignment2;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class lowStockItemsForm extends JDialog implements ActionListener{

	HashMap<String, Product> products = new HashMap<String, Product>(50);
	double total = 0.0;
	int[] gradeQuant = new int[5];
	int totalQuant = 0, count = 0;
	Product[] p;
	private JPanel jpHeader, jpDisplay;
	private JLabel lblHeader, lblMessage;
	private JTextArea taDisplay, taSummary, taProductHeader;
	private JButton jbExit, jbReport;
	lowStockItemsForm(HashMap productsMap)
	{
		products = productsMap;
		load();
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == jbExit)
		{
			dispose();
		}
		else if(e.getSource() == jbReport)
		{
			if(count == 0)
			{
				JOptionPane.showMessageDialog(null, "There are no low stock items.");
			}
			else
			{
				try {			
					sendToReport();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		
	}

	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		getContentPane().add(c, gc);
		
	}
	private void addComp(Container con, Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
		GridBagConstraints gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.insets = new Insets(5,5,5,5);
		gc.gridx = gridx;
		gc.gridy = gridy;
		gc.gridwidth = width;
		gc.gridheight = height;
		gc.weightx = weightX;
		gc.weighty = weightY;
		
		con.add(c,gc);
	}

	public void load()
	{
		for(int i =0;i<5;i++)
		{
			gradeQuant[i] = 0;
		}
		p = new Product[products.size()];
		Iterator i = products.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry me = (Entry) i.next();
			
			if(products.get(me.getKey()).getStockLevel() <= 10)
			{
				total += products.get(me.getKey()).getUnitPrice();
				p[count] = products.get(me.getKey());
				count++;
				switch(products.get(me.getKey()).getCategory())
				{
				case "Beauty": gradeQuant[0] = (gradeQuant[0] +1); break;
				case "Food": gradeQuant[1] = (gradeQuant[1] +1); break;
				case "Sports Nutrition": gradeQuant[2] = (gradeQuant[2] +1); break;
				case "Vitamins": gradeQuant[3] = (gradeQuant[3] +1); break;
				case "Weight Loss": gradeQuant[4] = (gradeQuant[4] +1); break;
				}			
			}
		}
		
		
		
		jpHeader = new JPanel();
		jpDisplay = new JPanel();
		
		jpHeader.setLayout(new GridBagLayout());
		jpDisplay.setLayout(new GridBagLayout());
		
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		
		addComp(jpHeader,0,0,2,1,1,0);
		addComp(jpDisplay,0,1,2,1,1,1);
		
		lblHeader = new JLabel("Low Stock Items.");
		lblMessage = new JLabel("These are items that have below a stock level of 10 or less.");
				
		addComp(jpHeader, lblHeader,0,0,1,1,1,0);
		addComp(jpHeader, lblMessage,0,1,1,1,1,0);
		
		
		
		taDisplay = new JTextArea();
		taDisplay.setEditable(false);
		taDisplay.setFont(new Font("Courier New", Font.PLAIN, 12));
		taSummary = new JTextArea();
		taSummary.setEditable(false);
		taSummary.setFont(new Font("Courier New", Font.PLAIN, 18));
		taProductHeader = new JTextArea("Product No:       Name:               Price:         Stock Level:          No Sold:  Size:");
		taProductHeader.setEditable(false);
		taProductHeader.setFont(new Font("Courier New", Font.PLAIN, 12));
		addComp(jpDisplay, taSummary,0,0,1,1,1,0);
		addComp(jpDisplay, taProductHeader,0,1,1,1,1,0);
		addComp(jpDisplay, taDisplay,0,2,1,1,1,1);
		
		String dis = "";
		totalQuant = (gradeQuant[0] +gradeQuant[1] +gradeQuant[2] +gradeQuant[3] +gradeQuant[4]);
		if(totalQuant == 0)
		{
			taSummary.setText("No low stock items.");
		}
		else
		{
			taSummary.setText("Total Low: " + totalQuant +"\tItems Price: " + total + 
					"\n\nBeauty: "
					 + gradeQuant[0] + "\tFood: " + gradeQuant[1]
					+"\tSports Nutrition: " + gradeQuant[2] + "\tVitamins: " + gradeQuant[3]
					+ "\tWeight Loss: " + gradeQuant[4]);
			for(int j = 0; j < totalQuant; j++)
			{
				dis += "\n";
				dis += String.format("%-18d%-20s%-15.2f%-22d%-10d%-20s", p[j].getProductID(),p[j].getName(), p[j].getUnitPrice(), p[j].getStockLevel(), p[j].getNoSold(), p[j].getSize());
			}
			taDisplay.setText(dis);
		}
		
		jbExit = new JButton("Exit");
		jbExit.addActionListener(this);
		jbReport = new JButton("Send to report");
		jbReport.addActionListener(this);
		
		addComp(jbExit,0,2,1,1,1,0);
		addComp(jbReport,1,2,1,1,1,0);
		
	}
	
	public void sendToReport() throws FileNotFoundException
	{
		String s = ("LowStockItems-" + LocalDateTime.now().getDayOfMonth() + "-"  + LocalDateTime.now().getMonthValue() + "-" + LocalDateTime.now().getYear() + ".txt");
		File inFile = new File(s);
		PrintWriter in = new PrintWriter(inFile);
		
		in.println("L O W   S T O C K   I T E M S   R E P O R T");
		in.println("-------------------------------------------");
		in.println(String.format("AMOUNT: " + count));
		in.println("");
		in.println("Product ID:       Name:               Price:         Stock Level:          No Sold:          Category:           Size:");
		in.println("-----------------------------------------------------------------------------------------------------------------");
		
		Iterator i = products.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry me = (Entry) i.next();	
			if(products.get(me.getKey()).getStockLevel() <= 10)
			{
				in.println(String.format("%-18d%-20s%-15.2f%-22d%-18d%-20s%-20s", products.get(me.getKey()).getProductID(), products.get(me.getKey()).getName(), products.get(me.getKey()).getUnitPrice(), products.get(me.getKey()).getStockLevel(), products.get(me.getKey()).getNoSold(), products.get(me.getKey()).getCategory(), products.get(me.getKey()).getSize()));                         
			}
		}
		
		in.println("");
		in.println("-----------------------------------------------------------------------------------------------------------------");
		in.println("REPORT FINISHED. DATE: " + LocalDateTime.now());
		in.println("-----------------------------------------------------------------------------------------------------------------");
		
		in.close();
		
	}
	
	
	
	
	
	
	
	
	
	
}
