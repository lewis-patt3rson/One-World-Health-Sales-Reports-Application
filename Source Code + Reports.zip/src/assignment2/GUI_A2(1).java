package assignment2;

import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.*;
import java.util.*;
import java.util.Map.Entry;

import javax.swing.*;



public class GUI_A2 extends JFrame implements ActionListener {

	private JMenuBar jmb;
	private JMenu ProductsMenu, Stock, Reports, System;
	private JMenuItem addProduct, updateProduct, deleteProduct, displayStock, makeSale, lowStockItems, productsByCategory, allSales, exit;
	HashMap<String, Product> products = new HashMap<String, Product>(50);
	HashMap<String, Product> productRead = new HashMap<String, Product>(50);
	
	LinkedList<Sale> sales = new LinkedList<Sale>();
	LinkedList<Sale> salesRead = new LinkedList<Sale>();
	
	File productFile = new File("stock.dat");
	File salesFile = new File("sales.dat");
	Product adderP;
	GUI_A2()
	{
//		Product[] intitalP = new Product[3];
//		intitalP[0] = new Product("aaa","aaa","Beauty",0,15,5.00);
//		intitalP[1] = new Product("bbb","bbb","Food",0,5,12.00);
//		intitalP[2] = new Product("ccc","ccc","Vitamins",0,30,60.00);
//		products.put(""+intitalP[0].getProductID(), intitalP[0]);
//		products.put(""+intitalP[1].getProductID(), intitalP[1]);
//		products.put(""+intitalP[2].getProductID(), intitalP[2]);
		
		try
		{
			FileInputStream fis = new FileInputStream(productFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			productRead = (HashMap<String, Product>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}
		
		String s = ("" + productRead.size());
		String id = "";
		products.putAll(productRead);
		adderP = new Product();
		adderP.setCount(1000 + productRead.size());
//		Iterator i = productRead.entrySet().iterator();
//		while(i.hasNext())
//		{				
//			Map.Entry me = (Entry) i.next();
//			id = (""+productRead.get(me.getKey()).getProductID());
//			adderP = new Product();
//			adderP.setName(productRead.get(me.getKey()).getName());
//			adderP.setCategory(productRead.get(me.getKey()).getCategory());
//			adderP.setUnitPrice(productRead.get(me.getKey()).getUnitPrice());
//			adderP.setStockLevel(productRead.get(me.getKey()).getStockLevel());
//			adderP.setSize(productRead.get(me.getKey()).getSize());
//			products.put(id, adderP);
//			
//		}
		try
		{
			FileInputStream fis = new FileInputStream(salesFile);
			ObjectInputStream ois = new ObjectInputStream(fis);
			sales = (LinkedList<Sale>) ois.readObject();
			ois.close();
			fis.close();
		}
		catch (ClassNotFoundException cEx)
		{
			JOptionPane.showMessageDialog(null, "The contents could not be read");
		}
		catch (FileNotFoundException fEx)
		{
			JOptionPane.showMessageDialog(null, "No file found");
		}
		catch (IOException ioEx)
		{
			JOptionPane.showMessageDialog(null, "Could not read from file");
		}
		for(int i = 0; i < salesRead.size(); i++)
		{
			sales.push(salesRead.get(i));
			sales.get(0).getCustomerName();
		}
		
		
		
		
		Container cn = getContentPane();
		cn.setLayout(new GridBagLayout());
		jmb = new JMenuBar();
		ProductsMenu = new JMenu("Products");
		Stock = new JMenu("Stock");
		Reports = new JMenu("Reports");
		System = new JMenu("System");
		addProduct = new JMenuItem("Add Product");
		updateProduct = new JMenuItem("Update Product");
		deleteProduct = new JMenuItem("Delete Product");
		displayStock = new JMenuItem("Display Stock");
		makeSale = new JMenuItem("Make Sale");
		lowStockItems = new JMenuItem("Low Stock Items");
		productsByCategory = new JMenuItem("Products By Category");
		allSales = new JMenuItem("All Sales");
		exit = new JMenuItem("Exit");
		
		ProductsMenu.add(addProduct);
		ProductsMenu.add(updateProduct);
		ProductsMenu.add(deleteProduct);
		Stock.add(displayStock);
		Stock.add(makeSale);
		Reports.add(lowStockItems);
		Reports.add(productsByCategory);
		Reports.add(allSales);
		System.add(exit);
		
		jmb.add(ProductsMenu);
		jmb.add(Stock);
		jmb.add(Reports);
		jmb.add(System);
		
		setJMenuBar(jmb);
		
		addProduct.addActionListener(this);
		updateProduct.addActionListener(this);
		deleteProduct.addActionListener(this);
		displayStock.addActionListener(this);
		makeSale.addActionListener(this);
		lowStockItems.addActionListener(this);
		productsByCategory.addActionListener(this);
		allSales.addActionListener(this);
		exit.addActionListener(this);
		
		ImageIcon im = new ImageIcon("Capture.png");
		JLabel h = new JLabel(im);
		addComp(h,0,0,1,1,1,1);
		
		
	}
	
	private void addComp(Component c, int gridx, int gridy, int width, int height, int weightX,int weightY)
	{
	GridBagConstraints gc = new GridBagConstraints();
	gc.fill = GridBagConstraints.BOTH;
	gc.insets = new Insets(5,5,5,5);
	gc.gridx = gridx;
	gc.gridy = gridy;
	gc.gridwidth = width;
	gc.gridheight = height;
	gc.weightx = weightX;
	gc.weighty = weightY;
	
	getContentPane().add(c, gc);
	
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == addProduct)
		{
			addProductForm apf = new addProductForm(products);
			apf.setSize(800,800);
			apf.setModal(true);
			apf.setVisible(true);
		}
		else if(e.getSource() == displayStock)
		{
			displayStockForm dsf = new displayStockForm(products);
			dsf.setSize(800,800);
			dsf.setModal(true);
			dsf.setVisible(true);
		}
		else if(e.getSource() == updateProduct)
		{
			UpdateProductForm upf = new UpdateProductForm(products,1);
			upf.setSize(800,800);
			upf.setModal(true);
			upf.setVisible(true);
		}
		else if(e.getSource() == deleteProduct)
		{
			UpdateProductForm upf = new UpdateProductForm(products,2);
			upf.setSize(800,800);
			upf.setModal(true);
			upf.setVisible(true);
		}
		else if(e.getSource() == lowStockItems)
		{		
			boolean low = false;
			Iterator i = products.entrySet().iterator();
			while(i.hasNext())
			{
				Map.Entry me = (Entry) i.next();
				
				if(products.get(me.getKey()).getStockLevel() <= 10)
				{
					low = true;
				}
			}
			
			if(products.size() == 0)
			{
				JOptionPane.showMessageDialog(null, "You must add a product before viewing low stock items.");
			}
			else if(!low)
			{
				
			}
			else
			{
				lowStockItemsForm lsif = new lowStockItemsForm(products);
				lsif.setSize(800,800);
				lsif.setModal(true);
				lsif.setVisible(true);
			}
		}
		else if(e.getSource() == makeSale)
		{
			if(products.size() == 0)
			{
				JOptionPane.showMessageDialog(null, "You must add a product before making a sale.");
			}
			else
			{
				makeSaleForm msf = new makeSaleForm(products, sales);
				msf.setSize(800,800);
				msf.setModal(true);
				msf.setVisible(true);
			}
		}
		else if(e.getSource() == productsByCategory)
		{
			if(products.size() == 0)
			{
				JOptionPane.showMessageDialog(null, "You must add a product before viewing products by category.");
			}
			else
			{
				productsByCategoryForm pbcf = new productsByCategoryForm(products);
				pbcf.setSize(800,800);
				pbcf.setModal(true);
				pbcf.setVisible(true);
			}
		}
		else if(e.getSource() == allSales)
		{
			if(sales.size() == 0)
			{
				JOptionPane.showMessageDialog(null, "You must add a sale in order to view all sales.");
			}
			else
			{
				allSalesForm asf = new allSalesForm(sales);
				asf.setSize(800,800);
				asf.setModal(true);
				asf.setVisible(true);
			}
		}
		else if(e.getSource() == exit)
		{
			try 
			{
				FileOutputStream fos = new FileOutputStream(productFile);
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				oos.writeObject(products);
				oos.close();
				fos.close();
			}
			catch(FileNotFoundException fEx)
			{
				JOptionPane.showMessageDialog(null, "No products file found");
			}
			catch(IOException ioEx)
			{
				JOptionPane.showMessageDialog(null, "Could not write products to file");
			}
			
			
			
			
			try 
			{
				FileOutputStream foos = new FileOutputStream(salesFile);
				ObjectOutputStream ooos = new ObjectOutputStream(foos);
				ooos.writeObject(sales);
				ooos.close();
				foos.close();
			}
			catch(FileNotFoundException fEx)
			{
				JOptionPane.showMessageDialog(null, "No sales file found");
			}
			catch(IOException ioEx)
			{
				JOptionPane.showMessageDialog(null, "Could not write sales to file");
				ioEx.printStackTrace();
			}
			dispose();
		}
	}
	
	public static void main(String[] args)
	{
		GUI_A2 test = new GUI_A2();
		test.setSize(800, 800);
		test.setVisible(true);
	}
}
