package assignment2;

public class Product implements java.io.Serializable{

	private int productID;
	private String name, size, category;
	private int noSold, stockLevel;
	private double unitPrice;
	private static int count = 1000;
	
	Product()
	{
		count ++;
		productID = count;
		name = "";
		size = "";
		category = "";
		noSold = 0;
		stockLevel = 0;
		unitPrice = 0.0;		
	}
	
	 Product(String name, String size, String category, int noSold, int stockLevel, double unitPrice)
	 {		
		count ++;
		productID = count;
		this.name = name;
		this.size = size;
		this.category = category;
		this.noSold = noSold;
		this.stockLevel = stockLevel;
		this.unitPrice = unitPrice;
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getNoSold() {
		return noSold;
	}

	public void setNoSold(int noSold) {
		this.noSold = noSold;
	}

	public int getStockLevel() {
		return stockLevel;
	}

	public void setStockLevel(int stockLevel) {
		this.stockLevel = stockLevel;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public int getCount()
	{
		return count;
	}
	public void setCount(int count)
	{
		this.count = count;
	}
	public void exitAdd()
	{
		count--;
	}
}
